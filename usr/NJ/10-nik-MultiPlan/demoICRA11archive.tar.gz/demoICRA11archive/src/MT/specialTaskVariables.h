#ifndef MT_specialTaskVariables_h
#define MT_specialTaskVariables_h

#include "ors.h"
#include "SD/ISF_GP.h"

//===========================================================================
//
// types
//

typedef MT::Array<ors::Shape*> ShapeList;

//a generic 3D potential, e.g., to represent an implicit surface
struct PotentialFunction{
  virtual double psi(arr* grad,const arr& x)=0;
};

//===========================================================================
//
// specific helpers to create standard sets of task variables and goals
//

void createStandardRobotTaskVariables(soc::SocSystem_Ors& sys,const char* objShape);
void setGraspGoals(soc::SocSystem_Ors& sys,uint T,const char* objShape);

//===========================================================================
//
// novel, more complex task variables
//

/* for n shapes describes the n-dim vector of values of a potential */
struct PotentialValuesTaskVariable:public TaskVariable{
  PotentialFunction *f;
  ShapeList refs;
  
  PotentialValuesTaskVariable(const char* _name, ors::Graph& _ors, ShapeList& _refs, PotentialFunction& _f);
  virtual void userUpdate();
};

struct PotentialFieldAlignTaskVariable:public TaskVariable{
  PotentialFunction *f;
  ShapeList refs;

  PotentialFieldAlignTaskVariable(const char* _name, ors::Graph& _ors, ShapeList& _refs, PotentialFunction& _f);
  virtual void userUpdate();
};

struct zOpposeTaskVariable:public TaskVariable{
  ShapeList refs;

  zOpposeTaskVariable(const char* _name, ors::Graph& _ors, ShapeList& _refs);
  virtual void userUpdate();
};

struct zFocusTargetTaskVariable:public TaskVariable{
  ShapeList refs;
  arr target;

  zFocusTargetTaskVariable(const char* _name, ors::Graph& _ors, ShapeList& _refs);
  virtual void userUpdate();
};


//===========================================================================
//
// generic grasp object that defines an implicit shape potential
//

//MT: move this to cpp file
double staticPhi(double x,double y,double z,void *p);
double static_mu(const arr&, const void *);

struct GraspObject : public PotentialFunction {
  ors::Mesh m;

  arr X,dX; //vector fields for plotting

  virtual double distanceToSurface(arr *grad,const arr& x){ NIY; }
  virtual double psi(arr* grad,const arr& x){return phi(grad,x);};
  virtual double phi(arr *grad,const arr& x){ //generic phi, based only on (scaled) distance to surface
    // see gnuplot:  plot[-1:4] 1.-exp(-.5*(x+1)*(x+1))/exp(-.5)
    double d=distanceToSurface(grad,x);
    if(d<-1.) d=-1.; 
    double phi=1.-exp(-.5*(d+1.)*(d+1.))/exp(-.5);
    if(grad){
      (*grad) = (-exp(-.5*(d+1.)*(d+1.))/exp(-.5)) * (-(d+1.)) * (*grad);
    }
    return phi;
  }
  void getNormGrad(arr& grad,const arr& x){
    phi(&grad,x);
    double d=norm(grad);
    if(d>1e-200) grad/=d; else MT_MSG("gradient too small!");
  }
  virtual void glDraw(){
    ors::glDraw(m);
  };
  void buildMesh(){
    uint i;
    arr c = MT::getParameter<arr>("center");

    m.setImplicitSurface(staticPhi,this,-1.3,1.3,100);
    X.setGrid(3,-.2,.2,40);
    dX.resizeAs(X);
    for(i=0;i<X.d0;i++){
      X[i]()+=c;
      phi(&dX[i](),X[i]);
    }
    dX *= .001;
    plotVectorField(X,dX);
  }
};

double staticPhi(double x,double y,double z,void *p){
  return ((GraspObject*)p)->phi(NULL,ARR(x,y,z));
}

double static_mu(const arr &x, const void *p){
  return ((GraspObject*)p)->phi(NULL,x);
}

void glDrawGraspObject(void*p){ ((GraspObject*)p)->glDraw(); }

struct GraspObject_InfCylinder:public GraspObject{
  arr c;    //center
  arr z;    //z orientation
  double r; //radius
  double s; //kernel parameter
  
  double distanceToSurface(arr *grad,const arr& x);
  GraspObject_InfCylinder();
};

struct GraspObject_Cylinder1:public GraspObject{ // poor man's cylinder 
  arr c;    //center
  arr z;    //z orientation
  double r; //radius
  double h; //height = 2 * (center to plane)
  double s; //kernel parameter
  
  double distanceToSurface(arr *grad,const arr& x);
  GraspObject_Cylinder1();
};

struct GraspObject_Sphere:public GraspObject{
  arr c;    //center
  double r; //radius
  double s; //kernel parameter
  
  double distanceToSurface(arr *grad,const arr& x);
  GraspObject_Sphere();
};

struct GraspObject_GP:public GraspObject{

  arr c;
  double d;
  isf_gp_t isf_gp;
  
  double phi(arr *grad,const arr& x);
  
  GraspObject_GP();
};

struct GraspObject_GPblob:public GraspObject_GP{ // blub demo

  GraspObject_GPblob();
};


struct GraspObject_GP_analytical_prior:public GraspObject_GP{ 

  GraspObject *prior;

  GraspObject_GP_analytical_prior(GraspObject *prior); 
};



#ifdef MT_IMPLEMENTATION
#include "specialTaskVariables.cpp"
#endif

#endif
