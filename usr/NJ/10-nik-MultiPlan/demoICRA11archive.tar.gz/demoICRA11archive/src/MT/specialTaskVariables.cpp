void createStandardRobotTaskVariables(soc::SocSystem_Ors& sys){
  arr limits;
  limits <<"[-2. 2.; -2. 2.; -2. 0.2; -2. 2.; -2. 0.2; -3. 3.; -2. 2.; \
      -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5 ]";
  arr I; I.setId(sys.ors->getJointStateDimension());
  //arr skinIdx; copy(skinIdx,ctrl->skinIndex);
  
  TaskVariable *TV_eff  = new TaskVariable("endeffector",*sys.ors, posTVT,"m9","<t(0 0 -.24)>",0,0,0);
  TaskVariable *TV_rot  = new TaskVariable("endeffector rotation",*sys.ors, rotTVT,"m9",0,0,0,0);
  TaskVariable *TV_col  = new TaskVariable("collision", *sys.ors, collTVT,0,0,0,0,ARR(.03)); //MARGIN, perhaps .05?
  TaskVariable *TV_lim  = new TaskVariable("limits", *sys.ors, qLimitsTVT,0,0,0,0,limits);
  TaskVariable *TV_q    = new TaskVariable("qitself", *sys.ors, qLinearTVT,0,0,0,0,I);
  //TaskVariable *TV_skin = new TaskVariable("skin", *sys.ors, skinTVT,0,0,0,0,skinIdx);
  TaskVariable *TV_up   = new TaskVariable("up1",*sys.ors, zalignTVT,"m9","<d(90 1 0 0)>",0,0,0);
  TaskVariable *TV_up2  = new TaskVariable("up2",*sys.ors, zalignTVT,"m9","<d( 0 1 0 0)>",0,0,0);
  TaskVariable *TV_z1   = new TaskVariable("oppose12",*sys.ors,zalignTVT,"tip1","<d(90 1 0 0)>","tip2","<d( 90 1 0 0)>",0);
  TaskVariable *TV_z2   = new TaskVariable("oppose13",*sys.ors,zalignTVT,"tip1","<d(90 1 0 0)>","tip3","<d( 90 1 0 0)>",0);
  TaskVariable *TV_f1   = new TaskVariable("pos1",*sys.ors,posTVT,"tip1","<t( .0   -.09 .0)>",0,0,0);
  TaskVariable *TV_f2   = new TaskVariable("pos2",*sys.ors,posTVT,"tip2","<t( .033 -.09 .0)>",0,0,0);
  TaskVariable *TV_f3   = new TaskVariable("pos3",*sys.ors,posTVT,"tip3","<t(-.033 -.09 .0)>",0,0,0);
  TaskVariableList TVs;
  TVs.append(TUPLE(TV_eff,TV_rot,TV_col,TV_lim,TV_q)); //TV_skin
  TVs.append(TUPLE(TV_up,TV_up2,TV_z1,TV_z2,TV_f1,TV_f2,TV_f3));
  sys.setTaskVariables(TVs);

}

void setGraspGoals(soc::SocSystem_Ors& sys,uint T,uint shapeId){
  sys.setq0AsCurrent();

  //load parameters only once!
  static bool firstTime=true;
  static double midPrec,endPrec,palmPrec,colPrec,limPrec,endVelPrec;
  if(firstTime){
    firstTime=false;
    MT::getParameter(midPrec,"reachPlanMidPrec");
    MT::getParameter(endPrec,"reachPlanEndPrec");
    MT::getParameter(palmPrec,"reachPlanPalmPrec");
    MT::getParameter(colPrec,"reachPlanColPrec");
    MT::getParameter(limPrec,"reachPlanLimPrec");
    MT::getParameter(endVelPrec,"reachPlanEndVelPrec");
  }
  
  //set the time horizon
  CHECK(T==sys.nTime(),"");
   
  //deactivate all variables
  activateAll(sys.vars,false);

  //activate collision testing with target shape
  ors::Shape *obj = sys.ors->shapes(shapeId);
  obj->cont=true;
  sys.swift->initActivations(*sys.ors);

  TaskVariable *V;

  //general target
  arr xtarget;
  xtarget.setCarray(obj->X.p.v,3);
  xtarget(2) += .02; //grasp it 2cm above center
    
  //endeff
  V=listGetByName(sys.vars,"endeffector");
  V->irel.setText("<t(0 0 -.26)>");
  V->updateState();
  V->y_target = xtarget;
  V->setInterpolatedTargetsEndPrecisions(T,midPrec,palmPrec,0.,0.);
    
  //up
  V=listGetByName(sys.vars,"up1");
  V->irel.setText("<d(90 1 0 0)>");
  V->updateState();
  V->y_target = 0.;
  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);

  //finger tips
  V=listGetByName(sys.vars,"pos1");  V->y_target = xtarget;  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);
  V=listGetByName(sys.vars,"pos2");  V->y_target = xtarget;  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);
  V=listGetByName(sys.vars,"pos3");  V->y_target = xtarget;  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);
    
  //opposing fingers
  V=listGetByName(sys.vars,"oppose12");  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);
  V=listGetByName(sys.vars,"oppose13");  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);

  //col lim and relax
  V=listGetByName(sys.vars,"collision");  V->y=0.;  V->y_target=0.;  V->setInterpolatedTargetsConstPrecisions(T,colPrec,0.);
  V=listGetByName(sys.vars,"limits");     V->y=0.;  V->y_target=0.;  V->setInterpolatedTargetsConstPrecisions(T,limPrec,0.);
  V=listGetByName(sys.vars,"qitself");    V->v=0.;  V->v_target=0.;  V->setInterpolatedTargetsEndPrecisions(T,0.,0.,midPrec,endVelPrec);
}

void setGraspGoals(soc::SocSystem_Ors& sys,uint T,const char* objShape){
  setGraspGoals(sys, T, sys.ors->getShapeByName(objShape)->index);
}

void setPlaceGoals(soc::SocSystem_Ors& sys,uint T,const char* objShape,const char* belowFromShape,const char* belowToShape){
  sys.setq0AsCurrent();

  //deactivate all variables
  activateAll(sys.vars,false);

  //activate collision testing with target shape
  ors::Shape *obj  = sys.ors->getShapeByName(objShape);
  ors::Shape *from = sys.ors->getShapeByName(belowFromShape);
  ors::Shape *onto = sys.ors->getShapeByName(belowToShape);
  CHECK(obj->body==sys.ors->getBodyByName("m9"),"called planPlaceTrajectory without right object in hand");
  obj->cont=true;
  onto->cont=false;
  from->cont=false;
  sys.swift->initActivations(*sys.ors);

  TaskVariable *V;

  //general target
  double midPrec,endPrec;
  MT::getParameter(midPrec,"reachPlanMidPrec");
  MT::getParameter(endPrec,"reachPlanEndPrec");
  arr xtarget;
  xtarget.setCarray(onto->X.p.v,3);
  xtarget(2) += .5*(onto->size[2]+obj->size[2])+.005; //above 'place' shape

  //endeff
  V=listGetByName(sys.vars,"endeffector");
  V->irel = obj->rel;
  V->updateState();
  V->y_target = xtarget;
  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);
  //special: condition effector velocities:
  uint t;
  for(t=0;t<50;t++){
    V -> v_trajectory[t]() = (.02*t)*ARR(0.,0.,.2);
    V -> v_prec_trajectory(t) = 1e1;
  }
  for(t=T-50;t<T;t++){
    V -> v_trajectory[t]() = (.02*(T-t))*ARR(0.,0.,-.2);
    V -> v_prec_trajectory(t) = 1e1;
  }

  //up1
  V=listGetByName(sys.vars,"up1");
  V->irel = obj->rel;  V -> irel.addRelativeRotationDeg(90,1,0,0);
  V->updateState();
  V->y_target = 0.;
  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);

  //up2
  V=listGetByName(sys.vars,"up2");
  V->irel = obj->rel;  V-> irel.addRelativeRotationDeg(90,0,1,0);
  V->updateState();
  V->y_target = 0.;
  V->setInterpolatedTargetsEndPrecisions(T,midPrec,endPrec,0.,0.);

  //col lim and relax
  V=listGetByName(sys.vars,"collision");  V->y=0.;  V->y_target=0.;  V->setInterpolatedTargetsConstPrecisions(T,MT::getParameter<double>("reachPlanColPrec"),0.);
  V=listGetByName(sys.vars,"limits");     V->y=0.;  V->y_target=0.;  V->setInterpolatedTargetsConstPrecisions(T,MT::getParameter<double>("reachPlanLimPrec"),0.);
  V=listGetByName(sys.vars,"qitself");    V->y=0.;  V->y_target=V->y; V->v=0.;  V->v_target=V->v;  V->setInterpolatedTargetsEndPrecisions(T,0.,0.,midPrec,MT::getParameter<double>("reachPlanEndVelPrec"));
}

PotentialValuesTaskVariable::PotentialValuesTaskVariable(const char* _name,
                              ors::Graph& _ors,
                              ShapeList& _refs,
                              PotentialFunction& _f){
  refs=_refs;
  f=&_f;
  set(_name, _ors, userTVT, -1, ors::Frame(), -1, ors::Frame(), ARR());
}

void PotentialValuesTaskVariable::userUpdate(){
  uint i;
  ors::Shape *s;
  arr xi,Ji,grad;
  y.resize(refs.N);
  //y_target.resize(refs.N);
  J.resize(refs.N,ors->getJointStateDimension());
  for_list(i,s,refs){
    ors->kinematics(xi,s->body->index,&s->rel);
    ors->jacobian  (Ji,s->body->index,&s->rel);
    y(i) = f->psi(&grad,xi);
    J[i]() = grad*Ji;
    //y_target(i) = -y(i);
  }
  transpose(Jt,J);
}

PotentialFieldAlignTaskVariable::PotentialFieldAlignTaskVariable(const char* _name,
    ors::Graph& _ors,
    ShapeList& _refs,
    PotentialFunction& _f){
      refs=_refs;
      f=&_f;
      set(_name, _ors, userTVT, -1, ors::Frame(), -1, ors::Frame(), ARR());
}

void PotentialFieldAlignTaskVariable::userUpdate(){
  uint i;
  ors::Shape *s;
  arr xi,zi,Ji,grad;
  y.resize(refs.N);
  J.resize(refs.N,ors->getJointStateDimension());
  for_list(i,s,refs){
    ors->kinematics (xi,s->body->index,&s->rel);
    ors->kinematicsZ(zi,s->body->index,&s->rel);
    ors->jacobianZ  (Ji,s->body->index,&s->rel);
    f->psi(&grad,xi);
    grad /= norm(grad);
      //zi /= norm(zi); -- kinematicsZ is always normalized (mt)
    y(i) = scalarProduct(zi,grad);
    J[i]() = ~grad * Ji; // + ~zi * Jgrad; actually we would need the Hessian!
  }
  transpose(Jt,J);
}

zOpposeTaskVariable::zOpposeTaskVariable(const char* _name,
                                         ors::Graph& _ors,
                                         ShapeList& _refs){
  refs=_refs;
  set(_name, _ors, userTVT, -1, ors::Frame(), -1, ors::Frame(), ARR());
}

void zOpposeTaskVariable::userUpdate(){
    //compute sum of z-vectors for n shapes
    //return sunOfSqr of this sum (is a scalar task variable)
  uint i;
  ors::Shape *s;
  arr zi,Ji,sum_z,sum_J;
  sum_J.resize(refs.N,ors->getJointStateDimension()); sum_J.setZero();
  sum_z.resize(3); sum_z.setZero();
  for_list(i,s,refs){
    ors->kinematicsZ(zi,s->body->index,&s->rel);
    sum_z += zi/norm(zi);
    ors->jacobianZ  (Ji,s->body->index,&s->rel);
    sum_J += Ji;
  }
  y.resize(1);
  y(0)=sumOfSqr(sum_z);
  J = 2.*sum_z*sum_J;
  J.reshape(1,ors->getJointStateDimension());
  transpose(Jt,J);
}

zFocusTargetTaskVariable::zFocusTargetTaskVariable(const char* _name,
    ors::Graph& _ors,
    ShapeList& _refs){
  refs=_refs;
  set(_name, _ors, userTVT, -1, ors::Frame(), -1, ors::Frame(), ARR());
}

void zFocusTargetTaskVariable::userUpdate(){
    //for all n shapes:
    //diff=target-shape->X.p;
    //z = shape->X.getZ();
    //offset = diff - <diff,z>*z;
    //return |offset|^2;
}

// ================= GraspObjects ==========================
// to be moved to own module


double
GraspObject_InfCylinder::distanceToSurface(arr *grad,const arr& x){
  z = z / norm(z);
  arr d_vec = (x-c) - scalarProduct((x-c), z) * z;
  double d = norm(d_vec);
  if(grad) *grad = s*d_vec/d;
  return s*(d-r);
}

GraspObject_InfCylinder::GraspObject_InfCylinder(){
  c = MT::getParameter<arr>("center");
  z = MT::getParameter<arr>("orientation");
  r = MT::getParameter<double>("radius");
  s = MT::getParameter<double>("sigma");
}

double
GraspObject_Cylinder1::distanceToSurface(arr *grad,const arr& x){
  z = z / norm(z);
  arr hx_vec = scalarProduct((x-c), z) * z;
  arr d_vec = (x-c) - hx_vec;
  double d = norm(d_vec);
  double hx = norm(hx_vec);
  if ( hx < h/2. ){ // x projection on z is inside cyl
    if(grad) *grad = s*d_vec/d;
    return s*(d-r);
  }else{// x projection on z is outside cylinder
    if ( d < r ){// inside the infinite cylinder
      if(grad) *grad = s*hx_vec/hx;
      return s*(hx-h/2.);
    }else{ // outside the infinite cyl
      arr vec =  hx_vec * hx / (hx+h/2.) + d_vec * d / (d+r);
      if(grad) *grad = s* vec / norm(vec); 
      return s* norm(vec);
    }
  }
}

GraspObject_Cylinder1::GraspObject_Cylinder1(){
  c = MT::getParameter<arr>("center");
  z = MT::getParameter<arr>("orientation");
  r = MT::getParameter<double>("radius");
  s = MT::getParameter<double>("sigma");
  h = MT::getParameter<double>("height");
}

double
GraspObject_Sphere::distanceToSurface(arr *grad,const arr& x){
  double d = norm(x-c);
  if(grad) *grad = s*(x-c)/d;
  return s*(d-r);
}

GraspObject_Sphere::GraspObject_Sphere(){
  c = MT::getParameter<arr>("center");
  r = MT::getParameter<double>("radius");
  s = MT::getParameter<double>("sigma");
}


double
GraspObject_GP::phi(arr *grad,const arr& x){
  double y, sig;
  //arr x = xx - c;

  isf_gp.gp.evaluate(x,y,sig); 

  if (grad) isf_gp.gp.gradient(*grad, x);

  //SD_DBG("x="<<x<<"; y="<<y<<" sig="<<sig<<" gradient="<<((grad)?*grad:0));

  return y;
}

GraspObject_GP::GraspObject_GP(){
  c = MT::getParameter<arr>("center");
  d = MT::getParameter<double>("objsize");

  isf_gp.set_size(d);
  //SD_DBG(*isf_gp);
}

GraspObject_GPblob::GraspObject_GPblob(){
  // generate object
  rnd.seed(MT::getParameter<uint>("seed", 1));
  randomGP_on_random_points(isf_gp.gp, c);
  isf_gp.gp.recompute();
}

GraspObject_GP_analytical_prior::GraspObject_GP_analytical_prior(GraspObject *_prior) {
  // the default constructors for GraspObject_GP have set the parameters at
  // this point

  //the def constr for the prior has set the params
  prior = _prior;
  
  // generate object around prior
  isf_gp.set_shape_prior(static_mu, prior);
  rnd.seed(MT::getParameter<uint>("seed", 1));
  randomGP_on_random_points(isf_gp.gp, c); // NOTE: c == prior.c
  isf_gp.gp.recompute();
}

