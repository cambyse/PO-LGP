#include "motionPlannerModule.h"
#include <MT/specialTaskVariables.h>

void ReceedingHorizonModule::open(){
  CHECK(sys_parent,"please set sys_parent before launching a ReceedingHorizonModule");
  sys=sys_parent->newClone(true);
  sys->os = &cout;
  
  planner.init(*sys,.7,.0,.0,1,0); //aico
  //planner.init(*sys,.7,0,0); //ilqg
  time_shift=0;
}

void ReceedingHorizonModule::step(){
  if(time_shift){
    shiftTargets(sys->vars,-time_shift);
    planner.shiftSolution(-time_shift); //shift everything 10 steps forward...
    time_shift=0;
  }
  planner.stepDynamic();
  bwdMsg_v   =planner.v;
  bwdMsg_Vinv=planner.Vinv;
  if(planner.cost<1.) planAvailable=true; else planAvailable=false;
}

void ReceedingHorizonModule::close(){
}

//===========================================================================

MotionPlannerModuleGroup::MotionPlannerModuleGroup(){
  graspTargetBodyId=-1;
}
void MotionPlannerModuleGroup::open(){
  recho.sys_parent=sys_parent;
  recho.threadOpen();
}
void MotionPlannerModuleGroup::step(){
  if(graspTargetBodyId==-1) return;
  static bool first=true;
  if(recho.threadIsReady() && first){
    ors::Shape *s = recho.sys->ors->bodies(graspTargetBodyId)->shapes(0);
    cout <<"*** triggering motion planning to shape " <<s->name <<endl;
    setGraspGoals(*recho.sys, recho.sys->nTime(), s->index); ///HERE IS THE LINK TO THE BRAIN!
    first=false;
  }
  recho.threadStepOrSkip(0);
}
void MotionPlannerModuleGroup::close(){
  recho.threadClose();
}
