#ifndef MT_perceptionModule_h
#define MT_perceptionModule_h

#include "vision.h"
#include "MT/ors.h"
//#include <NJ/VisionTrackRoutines.h>

struct Object{
  //-- 2d shape
  uint shapeType;
  arr shapeParamsL,shapeParamsR,shapePointsL,shapePointsR, visionCenter;

  //-- 3d information
  arr shapePoints3d;
  arr center3d,orsShapeParams;
  arr diagDiff;

};

typedef MT::Array<Object*> ObjectList;

struct PerceptionModule:public StepThread{
  //INPUT
  floatA hsvChannelsL,hsvChannelsR;
  arr objectType;

  //OUTPUT
  ObjectList objects;
  byteA disp;

  //PARAMETERS for camera projection 3d<->2d
  arr Pl,Pr;
  //AverageTrack avTrack;

  PerceptionModule():StepThread("PerceptionModule"){}

  void open();
  void step();
  void close(){};
};

void realizeObjectListInOrs(ors::Graph& ors, const ObjectList& objects);

//void copyShapeInfos(ors::Graph& A,const ors::Graph& B);
void copyBodyInfos(ors::Graph& A,const ors::Graph& B);

#ifdef MT_IMPLEMENTATION
#  include "perceptionModule.cpp"
#endif

#endif
