#ifndef MT_motionPlannerModule_h
#define MT_motionPlannerModule_h

struct ReceedingHorizonModule:public StepThread{
  soc::AICO planner;
  //soc::iLQG planner;
  soc::SocSystem_Ors *sys,*sys_parent;
  
  //OUTPUT
  bool planAvailable;
  arr bwdMsg_v,bwdMsg_Vinv;
  
  //INPUT
  arr q0,v0;
  uint time_shift;
  
  ReceedingHorizonModule():StepThread("ReceedingHorizon"){ sys_parent=NULL; planAvailable=false; };

  void open();
  void step();
  void close();
};

struct MotionPlannerModuleGroup{
  soc::SocSystem_Ors *sys_parent;
  ReceedingHorizonModule recho;
  int graspTargetBodyId;
  
  MotionPlannerModuleGroup();
  
  void open();
  void step();
  void close();
};

#ifdef MT_IMPLEMENTATION
#  include "motionPlannerModule.cpp"
#endif

#endif