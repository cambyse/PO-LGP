#include "earlyVisionModule.h"

#ifdef MT_CUDA

void EarlyVisionModule::step(){
  byteA img2,img3;
  CvMatDonor cvMatDonor;

  if(!cameraL.N) return;

  //downscale left image
  img2=cameraL;
  for(uint i=0;i<downScale;i++){
    img3=img2;
    img2.resize(img3.d0/2,img3.d1/2,3);
    cvPyrDown(CVMAT(img3), CVMAT(img2));
  }
  imgL=img2;

  //downscale right image
  img2=cameraR;
  for(uint i=0;i<downScale;i++){
    img3=img2;
    img2.resize(img3.d0/2,img3.d1/2,3);
    cvPyrDown(CVMAT(img3), CVMAT(img2));
  }
  imgR=img2;

  if(!samedim(lastImg,imgL)) lastImg=imgL;

  MT::openConfigFile(); //(reopens it)
  MT::getParameter(hsvTargets,"evisHsvTargets");
  uint hsvColors = hsvTargets.N/6;

  //== call to cuda
  MT::timerStart(true);
  //cout <<"cuda times:" <<flush;

  //-- create memory
  if(!imgL.p_device){
    uint W=imgL.d1,H=imgL.d0;
    hsvThetaL.resize(hsvColors,H,W);
    hsvThetaR.resize(hsvColors,H,W);
    motionTheta.resize(H,W);
    hsvBP.resize(H,W); hsvBP.setZero();
    hsvBPmsg.resize(H,W,4); hsvBPmsg.setZero();

    cuda_alloc(imgL);
    cuda_alloc(imgR);
    cuda_alloc(lastImg);
    cuda_alloc(hsvThetaL);
    cuda_alloc(hsvThetaR);
    cuda_alloc(hsvTargets);
    cuda_alloc(motionTheta);
    cuda_alloc(hsvBP);
    cuda_alloc(hsvBPmsg);
    //cout <<" alloc=" <<MT::timerRead(true) <<flush;
    cuda_upload(hsvBP);
    cuda_upload(hsvBPmsg);
    cuda_upload(lastImg);
  }

  //-- upload stuff
  cuda_upload(imgL);
  cuda_upload(imgR);
  cuda_upload(hsvTargets);
  //cout <<" up=" <<MT::timerRead(true) <<flush;

  //-- call to cuda
  CudaWorkspace WS =
    {imgL.d0*imgL.d1,imgL.d1,
     imgL.p_device, lastImg.p_device, imgR.p_device,
     hsvColors,
     hsvThetaL.p_device, hsvThetaR.p_device , hsvTargets.p_device,
     motionTheta.p_device, 20.f,
     //integTheta.p_device, 1., .1,
     hsvBP.p_device, hsvBPmsg.p_device, .5
    };
  earlyVision(WS,imgL.d0*imgL.d1,256);

  //-- download stuff
  lock.writeLock();
  //cout <<" process=" <<MT::timerRead(true) <<flush;
  //cuda_download(gray);
  //cuda_download(hsv);
  cuda_download(hsvThetaL);
  cuda_download(hsvThetaR);
  //cuda_download(motionTheta);
  //cuda_download(integTheta);
  //cuda_download(hsvBP);
  //cout <<" cudatime=" <<MT::timerRead(true) <<flush;

  //smooth thetas
  for(uint nc=0;nc< hsvColors; nc++){
    smooth(hsvThetaL[nc](),thetaSmoothing);//5 originally...
    smooth(hsvThetaR[nc](),thetaSmoothing);
  }

  lock.unlock();
  
  //== postprocess stuff
#if 0 //obsolete stuff -> moved to perceptionModule...
  floatA hsvCenters_intern;
  hsvCenters_intern.resize(4*hsvColors);  axisEnd.resize(4*hsvColors);
  //-- loop through all hsv targets
  for(uint nc = 0; nc < hsvColors; nc++){

    //-- left image
    floatA axisEndsL;
    floatA meanCenterL;
    uintA boxL,boxR;
    findMaxRegionInEvidence(axisEndsL,meanCenterL,boxL,hsvThetaL[nc]);
    if(timer.steps%5==0) cvRectangle(CVMAT(imgL), cvPoint(boxL(0),boxL(1)), cvPoint(boxL(2),boxL(3)), cvScalar(255,0,0), 3 );

    //-- right image
    floatA axisEndsR;
    floatA meanCenterR;
    findMaxRegionInEvidence(axisEndsR,meanCenterR,boxR,hsvThetaR[nc]);
    if(timer.steps%5==0)cvRectangle(CVMAT(imgR), cvPoint(boxR(0),boxR(1)), cvPoint(boxR(2),boxR(3)), cvScalar(255,0,0), 3 );

    //-- combine left&right
    hsvCenters_intern(0+nc*4) = meanCenterL(0);
    hsvCenters_intern(1+nc*4) = meanCenterL(1);
    hsvCenters_intern(2+nc*4) = meanCenterR(0);
    hsvCenters_intern(3+nc*4) = meanCenterR(1);
    axisEnd(0+nc*4) = axisEndsL(0);
    axisEnd(1+nc*4) = axisEndsL(1);
    axisEnd(2+nc*4) = axisEndsR(0);
    axisEnd(3+nc*4) = axisEndsR(1);
  }
  //cout <<" posttime=" <<MT::timerRead(true) <<flush;
  lock.writeLock();
  hsvCenters = hsvCenters_intern;
  lock.unlock();
  lastImg=imgL;
#endif

  //display stuff
  if(display){
    lock.readLock();
    byteA disp,tmp,tmp2;
    tmp2.resize(imgL.d0/2,imgL.d1/2,3);
    tmp .resize(imgL.d0/4,imgL.d1/4,3);
    cvPyrDown(CVMAT(imgL), CVMAT(tmp2));  cvPyrDown(CVMAT(tmp2), CVMAT(tmp));  disp.append(tmp);
    cvPyrDown(CVMAT(imgR), CVMAT(tmp2));  cvPyrDown(CVMAT(tmp2), CVMAT(tmp));  disp.append(tmp);
    cvPyrDown(CVMAT(evi2rgb(hsvThetaL[timer.steps%hsvColors]())), CVMAT(tmp2));  cvPyrDown(CVMAT(tmp2), CVMAT(tmp));  disp.append(tmp);//cycle with different found colors
    cvPyrDown(CVMAT(evi2rgb(hsvThetaR[timer.steps%hsvColors]())), CVMAT(tmp2));  cvPyrDown(CVMAT(tmp2), CVMAT(tmp));  disp.append(tmp);
    disp.reshape(disp.N/(tmp.d1*3),tmp.d1,3);
    cvShow(disp,"earlyVision");
    lock.unlock();
    //cout <<" displaytime=" <<MT::timerRead(true) <<endl;
  }

}
#undef W
void EarlyVisionModule::open(){
  cuda_init();
}
void EarlyVisionModule::close(){
  cuda_free(imgL);
  cuda_free(hsvThetaL);
}

#else //def MT_CUDA
void EarlyVisionModule::step(){ NIY; }
void EarlyVisionModule::open(){ NIY; }
void EarlyVisionModule::close(){ NIY; }
#endif //def MT_CUDA

