#ifndef MT_joystick_h
#define MT_joystick_h

#include <MT/array.h>
class jsJoystick;

struct JoystickInterface{
  jsJoystick *joy;
  intA state;
  uint n;
  void open();
  bool step(); //bool indicates change
};

#ifdef MT_IMPLEMENTATION
#  include "joystick.cpp"
#endif
                          
#endif
