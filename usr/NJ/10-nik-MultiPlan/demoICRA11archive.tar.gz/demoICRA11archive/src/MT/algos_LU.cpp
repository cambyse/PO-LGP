/*  Copyright 2009 Marc Toussaint
    email: mtoussai@cs.tu-berlin.de

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a COPYING file of the GNU General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/> */

#include "array.h"
#include "algos.h"

#define TINY 1.0e-20

void ludcmp(real **a, int n, int *indx, real *d);
void lubksb(real **a, int n, int *indx, real b[]);

namespace MT{
  real determinant_LU(const arr& X){
    CHECK(X.nd==2 && X.d0==X.d1,"");
    uint n=X.d0,i;
    arr LU;
    LU=X;
    int *idx=new int[n];
    real *d=new real[n];
    LU.getCarray();
    ludcmp(LU.pp,n,idx,d);
    real det=1.;
    for(i=0;i<n;i++) det *= LU(i,i);
    delete[] idx;
    delete[] d;

    //real ddet=determinant(X); CHECK(det==ddet,"");
    return det;
  }

  void inverse_LU(arr& Xinv,const arr& X){
    CHECK(X.nd==2 && X.d0==X.d1,"");
    uint n=X.d0,i,j;
    Xinv.resize(n,n);
    if(n==0) return;
    if(n==n && n==1){ Xinv(0,0)=1./X(0,0); return; }
    if(n==n && n==2){ inverse2d(Xinv,X); return; }
    arr LU;
    LU=X;
    LU.getCarray();
    int *idx=new int[n];
    real *d=new real[n];
    ludcmp(LU.pp,n,idx,d);
    //--
    arr col(n);
    for(j=0;j<n;j++){
      col.setZero();
      col(j)=1.0;
      lubksb(LU.pp,n,idx,col.p);
      for(i=0;i<n;i++) Xinv(i,j)=col(i);
    }

    delete[] idx;
    delete[] d;

#ifdef MT_CHECK_INVERSE
    arr D,_D; D.setId(n);
    uint me;
    _D=X*Xinv;
    real err=maxDiff(_D,D,&me);
    CHECK(err<MT_CHECK_INVERSE ,"inverting failed, error="<<err <<" " <<_D.elem(me) <<"!=" <<D.elem(me));
#endif
  }

  void LU_decomposition(arr& L,arr& U,const arr& X){
    CHECK(X.nd==2 && X.d0==X.d1,"");
    uint n=X.d0,i,j;
    arr LU;
    LU=X;
    intA idx(n);
    doubleA d(n);
    LU.getCarray();

    ludcmp(LU.pp,n,idx.p,d.p);

    L.resizeAs(LU);  L.setZero();
    U.resizeAs(LU);  U.setZero();
    for(i=0;i<n;i++){
      for(j=0;j<i;j++)  L(i,j) = LU(i,j);
      L(i,i)=1.;
      for(;j<n;j++)     U(i,j) = LU(i,j);
    }
    cout <<X <<endl <<L*U <<endl <<idx <<endl <<d <<endl;
  }
}


void ludcmp(real **a, int n, int *indx, real *d){
  int i,imax=0,j,k;
  real big,dum,sum,temp;
  real *vv;
  vv=vector(1,n);
  *d=1.0; 
  for (i=0;i<n;i++) {
    big=     0.0; 
    for (j=0;j<n;j++)
      if ((temp=fabs(a[i][j])) > big) big=temp;
    if (big == 0.0) nrerror("Singular matrix in routine ludcmp");
    vv[i]=1.0/big; 
  }
  for (j=0;j<n;j++) { 
    for (i=0;i<j;i++) { 
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0; 
    for (i=j;i<n;i++) {
      sum=a[i][j]; 
      for (k=0;k<j;k++)
	sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
	big=dum;
	imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) { 
	dum=a[imax][k];
	a[imax][k]=a[j][k];
	a[j][k]=dum;
      }
      *d = -(*d); 
      vv[imax]=vv[j]; 
    }
    indx[j]=imax;
    if (a[j][j] == 0.0) a[j][j]=TINY;
  
    if (j != n) { 
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  } 
  free_vector(vv,1,n);
}


void lubksb(real **a, int n, int *indx, real b[]){
  int i,ii=0,ip,j;
  real sum;
  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i; 
    b[i]=sum; 
  }
  for (i=n;i--;) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i]; 
  } 
}
