#ifndef MT_guiModule_h
#define MT_guiModule_h

#include "array.h"

struct OpenGL;
struct RobotModuleGroup;
struct Object;
namespace ors{ struct Graph; }

struct GuiModule:public StepThread{
  //INPUT
  byteA img[6]; // 6 images for the view ports
  MT::Array<Object*> objects;
  arr q_reference;  // joint state of current robot
  arr q_trajectory, q_external; // a trajectory to display
  bool dispTrajectory;
  int dispSteps;

  //OUTPUT (none)

  //INTERNAL
#ifdef MT_QT
  QApplication *app;
#endif
  bool useOpengl,logData,plotData;
  OpenGL *gl;
  ors::Graph *ors,*ors2;
  RobotModuleGroup  *ctrl;
  bool isOpen;
 
#ifdef MT_QT
  Ui_SchunkMonitor *ui;
#endif
  

  
  GuiModule();
  ~GuiModule();
  
  void createOrsClones(ors::Graph *_ors);
  
  void open();
  void step();
  void close();
};


#ifdef MT_IMPLEMENTATION
#  include "guiModule.cpp"
#endif

#endif
