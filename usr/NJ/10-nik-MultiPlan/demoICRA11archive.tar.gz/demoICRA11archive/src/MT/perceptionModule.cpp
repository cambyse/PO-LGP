#include "perceptionModule.h"
#include "optimization.h"
#include "../src/NJ/VisionTrackRoutines.h"

//===========================================================================
//
// fwd declared helper routines
//

void generateShapePoints(arr& points, arr& weights, arr *grad, uint type, uint N, const arr& params);



//===========================================================================
//
// implementation of helper routines
//

void generateShapePoints(arr& points, arr& weights, arr *grad, uint type, uint N, const arr& params){
  if(type==0){ //cirlce
    CHECK(params.N==3,""); //posx posy radius
    points.resize(N,2);
    weights.resize(N); weights=1.;
    if(grad){ grad->resize(N,2,3);  grad->setZero(); }
    for(uint i=0;i<N;i++){
      points(i,0) = params(0) + cos(MT_2PI/N*i)*params(2);  if(grad){ (*grad)(i,0,0) = 1.;  (*grad)(i,0,2) = cos(MT_2PI/N*i); }
      points(i,1) = params(1) + sin(MT_2PI/N*i)*params(2);  if(grad){ (*grad)(i,1,1) = 1.;  (*grad)(i,1,2) = sin(MT_2PI/N*i); }
    }
    return;
  }
  if(type==1){ //cylinder
    CHECK(params.N==5,"cylinder needs 5 params"); //posx posy diameter height curve-height
    points.resize(4*N,2);
    weights.resize(4*N);
    if(grad){ grad->resize(4*N,2,5);  grad->setZero(); }
    //left bar
    for(uint i=0;i<N;i++){
      points(i,0) = params(0) - .5*params(2);                      if(grad){ (*grad)(i,0,0) = 1.;  (*grad)(i,0,2) =  -.5; }
      points(i,1) = params(1) - .5*params(3) + params(3)*i/(N-1);  if(grad){ (*grad)(i,1,1) = 1.;  (*grad)(i,1,3) =  -.5+double(i)/(N-1); }
      weights(i) = params(3);
    }
    //right bar
    for(uint i=0;i<N;i++){
      points(N+i,0) = params(0) + .5*params(2);                      if(grad){ (*grad)(N+i,0,0) = 1.;  (*grad)(N+i,0,2) =  +.5; }
      points(N+i,1) = params(1) - .5*params(3) + params(3)*i/(N-1);  if(grad){ (*grad)(N+i,1,1) = 1.;  (*grad)(N+i,1,3) =  -.5+double(i)/(N-1); }
      weights(N+i) = params(3);
    }
    //top curve
    for(uint i=0;i<N;i++){
      points(2*N+i,0) = params(0) + cos(MT_PI*(i+1)/(N+1))*.5*params(2);              if(grad){ (*grad)(2*N+i,0,0) = 1.;  (*grad)(2*N+i,0,2) = cos(MT_PI*(i+1)/(N+1))*.5; }
      points(2*N+i,1) = params(1) + .5*params(3) + sin(MT_PI*(i+1)/(N+1))*params(4);  if(grad){ (*grad)(2*N+i,1,1) = 1.;  (*grad)(2*N+i,1,3) = +.5;  (*grad)(2*N+i,1,4) = +sin(MT_PI*(i+1)/(N+1)); }
      weights(2*N+i) = params(2); //MT_PI * sqrt(*params(2)/8. + params(4)*params(4)/2.);
    }
    //bottom curve
    for(uint i=0;i<N;i++){
      points(3*N+i,0) = params(0) + cos(MT_PI*(i+1)/(N+1))*.5*params(2);              if(grad){ (*grad)(3*N+i,0,0) = 1.;  (*grad)(3*N+i,0,2) = cos(MT_PI*(i+1)/(N+1))*.5; }
      points(3*N+i,1) = params(1) - .5*params(3) - sin(MT_PI*(i+1)/(N+1))*params(4);  if(grad){ (*grad)(3*N+i,1,1) = 1.;  (*grad)(3*N+i,1,3) = -.5;  (*grad)(3*N+i,1,4) = -sin(MT_PI*(i+1)/(N+1)); }
      weights(3*N+i) = params(2);
    }
    return;
  }
#if 0
  if(type==2){ //box
    CHECK(params.N==6,"box needs 6 params"); //posx posy width height dx dy
    points.resize(4*N,2);
    weights.resize(4*N);
    if(grad){ grad->resize(4*N,2,6);  grad->setZero(); }
    //if(params(4)<0.){ params(4) *= -1.; params(5) *= -1.; }
    //vertical bars
    for(uint i=0;i<N;i++){
      points(i,0) = params(0) - .5*params(2) - .5*MT::sign(params(4))*params(4);                      if(grad){ (*grad)(i,0,0)=1.;  (*grad)(i,0,2)=-.5;                  (*grad)(i,0,4)=-.5*MT::sign(params(4)); }
      points(i,1) = params(1) - .5*params(3) - .5*MT::sign(params(4))*params(5) + params(3)*i/(N-1);  if(grad){ (*grad)(i,1,1)=1.;  (*grad)(i,1,3)=-.5+double(i)/(N-1);  (*grad)(i,1,5)=-.5*MT::sign(params(4));  }
      weights(i) = params(3);
    }
    for(uint i=0;i<N;i++){
      points(N+i,0) = params(0) + .5*params(2) + .5*MT::sign(params(4))*params(4);                      if(grad){ (*grad)(N+i,0,0)=1.;  (*grad)(N+i,0,2)=+.5;                  (*grad)(N+i,0,4)=+.5*MT::sign(params(4)); }
      points(N+i,1) = params(1) - .5*params(3) + .5*MT::sign(params(4))*params(5) + params(3)*i/(N-1);  if(grad){ (*grad)(N+i,1,1)=1.;  (*grad)(N+i,1,3)=-.5+double(i)/(N-1);  (*grad)(N+i,1,5)=+.5*MT::sign(params(4)); }
      weights(N+i) = params(3);
    }
    //horizontal bars
    for(uint i=0;i<N;i++){
      points(2*N+i,0) = params(0) - .5*params(2) - .5*MT::sign(params(5))*params(4) + params(2)*i/(N-1);   if(grad){ (*grad)(2*N+i,0,0)=1.;  (*grad)(2*N+i,0,2)=-.5+double(i)/(N-1);  (*grad)(2*N+i,0,4)=-.5*MT::sign(params(5));  }
      points(2*N+i,1) = params(1) - .5*params(3) - .5*MT::sign(params(5))*params(5);                       if(grad){ (*grad)(2*N+i,1,1)=1.;  (*grad)(2*N+i,1,3)=-.5;                  (*grad)(2*N+i,1,5)=-.5*MT::sign(params(5)); }
      weights(2*N+i) = params(3);
    }
    for(uint i=0;i<N;i++){
      points(3*N+i,0) = params(0) - .5*params(2) + .5*MT::sign(params(5))*params(4) + params(2)*i/(N-1);   if(grad){ (*grad)(3*N+i,0,0)=1.;  (*grad)(3*N+i,0,2)=-.5+double(i)/(N-1);  (*grad)(3*N+i,0,4)=+.5*MT::sign(params(5));  }
      points(3*N+i,1) = params(1) + .5*params(3) + .5*MT::sign(params(5))*params(5);                       if(grad){ (*grad)(3*N+i,1,1)=1.;  (*grad)(3*N+i,1,3)=+.5;                  (*grad)(3*N+i,1,5)=+.5*MT::sign(params(5)); }
      weights(3*N+i) = params(3);
    }
    return;
  }
#endif
  if(type==2){ //box
    CHECK(params.N==8,"box needs 8 params"); //posx posy dx1 dy1 dx2 dy2 dx3 dy3
    uint K=6,k;
    points.resize(K*N,2);
    weights.resize(K*N);
    if(grad){ grad->resize(K*N,2,8);  grad->setZero(); }
    //base -> 1
    k=0;
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(2)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=1.;  (*grad)(k*N+i,0,2)=double(i)/(N-1); }
      points(k*N+i,1) = params(1) + params(3)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=1.;  (*grad)(k*N+i,1,3)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(2)*params(2)+params(3)*params(3));
    }
    //base -> 1 -> 2
    k=1;
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(2) + params(4)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=(*grad)(k*N+i,0,2)=1.;  (*grad)(k*N+i,0,4)=double(i)/(N-1);  }
      points(k*N+i,1) = params(1) + params(3) + params(5)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=(*grad)(k*N+i,1,3)=1.;  (*grad)(k*N+i,1,5)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(4)*params(4)+params(5)*params(5));
    }
    //base -> 1 -> 2 -> 3
    k=2;
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(2) + params(4) + params(6)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=(*grad)(k*N+i,0,2)=(*grad)(k*N+i,0,4)=1.;  (*grad)(k*N+i,0,6)=double(i)/(N-1); }
      points(k*N+i,1) = params(1) + params(3) + params(5) + params(7)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=(*grad)(k*N+i,1,3)=(*grad)(k*N+i,1,5)=1.;  (*grad)(k*N+i,1,7)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(6)*params(6)+params(7)*params(7));
    }
    k=3;
    //base -> 3
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(6)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=1.;  (*grad)(k*N+i,0,6)=double(i)/(N-1); }
      points(k*N+i,1) = params(1) + params(7)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=1.;  (*grad)(k*N+i,1,7)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(6)*params(6)+params(7)*params(7));
    }
    k=4;
    //base -> 3 -> 2
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(6) + params(4)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=(*grad)(k*N+i,0,6)=1.;  (*grad)(k*N+i,0,4)=double(i)/(N-1); }
      points(k*N+i,1) = params(1) + params(7) + params(5)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=(*grad)(k*N+i,1,7)=1.;  (*grad)(k*N+i,1,5)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(4)*params(4)+params(5)*params(5));
    }
    //base -> 3 -> 2 -> 1
    k=5;
    for(uint i=0;i<N;i++){
      points(k*N+i,0) = params(0) + params(6) + params(4) + params(2)*i/(N-1);  if(grad){ (*grad)(k*N+i,0,0)=(*grad)(k*N+i,0,4)=(*grad)(k*N+i,0,6)=1.;  (*grad)(k*N+i,0,2)=double(i)/(N-1); }
      points(k*N+i,1) = params(1) + params(7) + params(5) + params(3)*i/(N-1);  if(grad){ (*grad)(k*N+i,1,1)=(*grad)(k*N+i,1,5)=(*grad)(k*N+i,1,7)=1.;  (*grad)(k*N+i,1,3)=double(i)/(N-1); }
      weights(k*N+i)  = sqrt(params(2)*params(2)+params(3)*params(3));
    }
    return;
  }
  if(type==3){ //6-polygon
    CHECK(params.N==12,"6-plygon needs 12 params"); //posx posy dx1 dy1 dx2 dy2 dx3 dy3
    uint K=6,k,kp;
    points.resize(K*N,2);
    weights.resize(K*N);
    if(grad){ grad->resize(K*N,2,12);  grad->setZero(); }
    for(k=0;k<6;k++){
      kp=k+1; kp=kp%6;
      for(uint i=0;i<N;i++){
        double a=double(i)/(N-1);
        points(k*N+i,0) = (1.-a)*params(2*k+0) + a*params(2*kp+0);  if(grad){ (*grad)(k*N+i,0,2*k+0)=1.-a;  (*grad)(k*N+i,0,2*kp+0)=a; }
        points(k*N+i,1) = (1.-a)*params(2*k+1) + a*params(2*kp+1);  if(grad){ (*grad)(k*N+i,1,2*k+1)=1.-a;  (*grad)(k*N+i,1,2*kp+1)=a; }
        weights(k*N+i)  = sqrt(MT::sqr(params(2*k+0)-params(2*kp+0))+MT::sqr(params(2*k+1)-params(2*kp+1)));
      }
    }
    return;
  }
  HALT("don't know that shape type");
};

struct ShapeFitProblem:public OptimizationProblem{
  floatA distImage;
  uint type,N;
  arr x,points;
  bool display;

  double f(arr *grad,const arr& x,int i=-1){
    double cost=0.;
    arr weights,dfdpoints;
    generateShapePoints(points,weights,grad,type,N,x);
    if(grad){  dfdpoints.resizeAs(points);  dfdpoints.setZero();  }
    for(uint i=0;i<points.d0;i++){ //interpolate...
      uint x=points(i,0), y=points(i,1);
      if(x>=distImage.d1-1) x=distImage.d1-2;
      if(y>=distImage.d0-1) y=distImage.d0-2;
      double a=fmod(points(i,0),1.), b=fmod(points(i,1),1.);
      if(a+b<1.){
        cost += weights(i)*((1.-a-b)*distImage(y,x) + a*distImage(y,x+1) + b*distImage(y+1,x));
        if(grad){
          dfdpoints(i,0) = weights(i)*(distImage(y,x+1) - distImage(y,x));
          dfdpoints(i,1) = weights(i)*(distImage(y+1,x) - distImage(y,x));
        }
      }else{
        cost += weights(i)*((a+b-1.)*distImage(y+1,x+1) + (1.-a)*distImage(y+1,x) + (1.-b)*distImage(y,x+1));
        if(grad){
          dfdpoints(i,0) = weights(i)*(distImage(y+1,x+1) - distImage(y+1,x));
          dfdpoints(i,1) = weights(i)*(distImage(y+1,x+1) - distImage(y,x+1));
        }
      }
    }
    if(grad){
      dfdpoints.reshape(dfdpoints.N);
      grad->reshape(dfdpoints.N,x.N);
      (*grad) = dfdpoints*(*grad);
    }
    if(display){
      byteA img;
      copy(img,10.f*distImage);
      cvDrawPoints(img,points);
      //cout <<x <<endl;
      //if(grad) cout <<*grad <<endl;
      cvShow(img,"shape optimization",true);
    }
    return cost;
  }
};

bool getShapeParamsFromEvidence(const uint& type,arr& params,arr& points,const floatA& theta,byteA *disp=NULL){
  CvMatDonor cvMatDonor;
  if(disp){
    *disp=evi2rgb(theta);
    //cvShow(*disp,"getShapeParamsFromEvidence",false);
  }

#if 1
  //flood fill
  uint W=theta.d1;
  uint i=theta.maxIndex(); float max1 = theta.elem(i);
  if(max1 < 0.6) return false;//assume no detection when unsure....
  CvConnectedComp component;
  byteA mask(theta.d0+2,theta.d1+2); mask.setZero();
  cvFloodFill(CVMAT(theta), cvPoint(i%W,i/W), cvScalar(1.f),
      cvScalar(0.5f), cvScalar(0.5f),
      &component, CV_FLOODFILL_FIXED_RANGE|CV_FLOODFILL_MASK_ONLY, CVMAT(mask) );//4th and 5th parameter are flood tolerance, 0.3 originally
#else
  //threshold
  uint maxi=theta.maxIndex(); float max1 = theta.elem(maxi); if(max1 < 0.6) return;//assume no detection when unsure....
  //uint W=theta.d1;
  byteA mask(theta.d0,theta.d1);
  cvThreshold(CVMAT(theta), CVMAT(mask), max1-.3f, 1.f, CV_THRESH_BINARY);
#endif

  //cvShow(byte(255)*mask,"mask",true);

  //draw a contour image
  CvMemStorage* storage = cvCreateMemStorage(0);
  CvSeq* contour = 0;
  cvFindContours( CVMAT(mask), storage, &contour, sizeof(CvContour), CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cvPoint(-1, -1));
  byteA contourImage; resizeAs(contourImage,theta); contourImage.setZero(255);
  cvDrawContours( CVMAT(contourImage), contour, cvScalar(0.f), cvScalar(128.f), 0 );
  if(disp){
    cvDrawContours( CVMAT(*disp), contour, cvScalar(255,100,100), cvScalar(200,100,100), 0 );
    //cvShow(*disp,"getShapeParamsFromEvidence",false);
  }
  cvClearMemStorage(storage);
  cvClearSeq(contour);


  //distance image
  floatA distImage; distImage.resizeAs(theta); distImage.setZero();
  cvDistTransform( CVMAT(contourImage), CVMAT(distImage), CV_DIST_L2, 5);
  //cvShow(.01f*(distImage),"distance",true);

  //multiple restarts for fitting
  arr bestParams;
  double bestCost=0.;
  ShapeFitProblem problem;
  for(uint k=0;k<2;k++){
    switch(type){
    case 0: //sphere
      params = ARR(component.rect.x + 0.5*component.rect.width,
          component.rect.y + 0.5*component.rect.height,
          (component.rect.width+component.rect.width)/4.);
      break;
    case 1: //cylinder
      params = ARR(component.rect.x + 0.5*component.rect.width,
          component.rect.y + 0.5*component.rect.height,
          component.rect.width,
          .7*component.rect.height,
          .2*component.rect.height);
      break;
    case 2: //box
      params = ARR(component.rect.x + .5*component.rect.width,
          component.rect.y,
          .5*component.rect.width, .2*component.rect.height,
          0, .8*component.rect.height,
          -.5*component.rect.width, .2*component.rect.height);
      break;
    case 3: //polygon
      params.setText("[ 0, 0, .5, -.2,  1, 0,  1, 1,  .5, 1.2,  0, 1]");
      for(uint k=0;k<6;k++){
        params(2*k+0) = component.rect.x + component.rect.width *params(2*k+0);
        params(2*k+1) = component.rect.y + component.rect.height*params(2*k+1);
      }
    default: HALT("");
    }
    rndUniform(params,-5.,5.,true);

    problem.type=type;
    problem.N=20;
    problem.distImage = pow(distImage,2.f);
    problem.display = false;

    MT::timerStart();
    double cost;
    Rprop rprop;
    rprop.dMax = 5.;
    rprop.init(3.);
    rprop.loop(params,problem,&cost,1.e-1,100);
    // cout <<"*** cost=" <<cost <<" params=" <<params <<" time=" <<MT::timerRead() <<endl;

    problem.f(NULL,params);
    byteA img; copy(img,10.f*problem.distImage);
    cvDrawPoints(img,problem.points);
    //cvShow(img,"shape optimization",false);

    if(!bestParams.N || cost<bestCost){
      bestCost=cost;  bestParams=params;
    }
  }

  //cout <<"best cost=" << bestCost <<" params=" <<bestParams <<endl;
  //type=2;
  params=bestParams;
  points=problem.points;

  if(disp){
    cvDrawPoints(*disp,problem.points);
    //cvShow(*disp,"getShapeParamsFromEvidence",false);
  }

  return true;
}


void PerceptionModule::open(){
  arr p2;
  MT::load(p2, "../../src/NJ/regparams");
  Pl = p2.sub(0,2,0,3);
  Pr = p2.sub(3,5,0,3);
  MT::getParameter(objectType,"percObjectType");
}

//===========================================================================
//
// cost step routine
//



void PerceptionModule::step(){
  CvMatDonor cvMatDonor;

  if(!hsvChannelsL.N) return;
  Object *obj;
  bool suc;
  ObjectList objs;
  lock.readLock();
  floatA hsvL(hsvChannelsL),hsvR(hsvChannelsR);
  lock.unlock();
  disp = evi2rgb(hsvL[0]);
  for(uint h=0;h<hsvL.d0;h++){
    obj=new Object;
    obj->shapeType = (uint)objectType(h);

    if(obj->shapeType <= 2){
      suc=getShapeParamsFromEvidence(obj->shapeType,
          obj->shapeParamsL,
          obj->shapePointsL,
          hsvL[h],&disp);
      if(!suc){ delete obj; continue; }
      suc=getShapeParamsFromEvidence(obj->shapeType,
          obj->shapeParamsR,
          obj->shapePointsR,
          hsvR[h]);
      if(!suc){ delete obj; continue; }

      //use only bars
      // obj->shapePointsR.resizeCopy(obj->shapePointsR.d0/2,2);
      // obj->shapePointsL.resizeCopy(obj->shapePointsL.d0/2,2);

      // nik: 3d...
      obj->shapePoints3d.resize(obj->shapePointsR.d0, 3);
      for (uint i = 0; i < obj->shapePoints3d.d0;  i++){
        arr vision(4);
        vision(0) = obj->shapePointsL(i,0);
        vision(1) = obj->shapePointsL(i,1);
        vision(2) = obj->shapePointsR(i,0);
        vision(3) = obj->shapePointsR(i,1);
        obj->shapePoints3d[i] =  Find3dPoint(Pl,Pr,vision);
      }
      //cout << " shapeR " << ~obj->shapePointsR.sub(0,obj->shapePointsR.d0-1,0,0) << endl;
      // <<  ~obj->shapePointsR << endl
      // << ~obj->shapePoints3d << endl << endl;

      //ors params
      uint n=obj->shapePoints3d.d0;
      arr ones(obj->shapePoints3d.d0); ones=1./n;
      obj->center3d = ones * obj->shapePoints3d;

      arr vis1 = ones*obj->shapePointsL;
      arr vis2 = ones*obj->shapePointsR;
      obj->visionCenter = arr(4);
      obj->visionCenter(0) = vis1(0);
      obj->visionCenter(1) = vis1(1);
      obj->visionCenter(2) = vis2(0);
      obj->visionCenter(3) = vis2(1);

      if(obj->shapeType == 1){//cylinder
        double h=
            .5*(norm(obj->shapePoints3d[0*n/2]-obj->shapePoints3d[1*n/2-1]) + //rigth side bar
                norm(obj->shapePoints3d[1*n/2]-obj->shapePoints3d[2*n/2-1])); //left side bar
        double r;
        for(uint i=0;i<n/2;i++) r += norm(obj->shapePoints3d[i]-obj->shapePoints3d[n/2+i])/2.;
        r /= n/2;
        obj->orsShapeParams=ARR(0.,0.,h,r);
      }
      if(obj->shapeType == 2 ){//box
        double h=
            .5*(norm(obj->shapePoints3d[1*n/6]-obj->shapePoints3d[2*n/6-1]) +  //rigth side bar
                norm(obj->shapePoints3d[4*n/6]-obj->shapePoints3d[5*n/6-1]));  //left side bar
        double x=
            .5*(norm(obj->shapePoints3d[0*n/6]-obj->shapePoints3d[1*n/6-1]) +  //rigth side bar
                norm(obj->shapePoints3d[3*n/6]-obj->shapePoints3d[4*n/6-1]));  //left side bar
        double y=
            .5*(norm(obj->shapePoints3d[2*n/6]-obj->shapePoints3d[3*n/6-1]) +  //rigth side bar
                norm(obj->shapePoints3d[5*n/6]-obj->shapePoints3d[6*n/6-1]));  //left side bar

        obj->diagDiff = obj->shapePoints3d[3*n/6] - obj->shapePoints3d[4*n/6];
        //for (uint d = 0; d < 6; d++)
        //  cout << obj->shapePoints3d[d*n/6] << endl;
        obj->orsShapeParams=ARR(x,y,h,0);
      }
      if(obj->shapeType == 0){//sphere
        double r;
        for(uint i=0;i<n;i++) r+=norm(obj->shapePoints3d[0]-obj->center3d); //mitteln ueber alle punkte!
        r/=n;
        obj->orsShapeParams=ARR(0.,0.,0.,r);
      }
    }
    else{//other index is just point mass, just single contour point
      uintA boxL,boxr;floatA axis,points;
      findMaxRegionInEvidence(axis,points ,boxL, hsvL[h]);//just use this information
      obj->shapePointsL = arr(1,2);
      obj->shapePointsL(0,0) = points(0);
      obj->shapePointsL(0,1) = points(1);
      findMaxRegionInEvidence(axis,points ,boxr, hsvR[h]);//just use this information
      obj->shapePointsR = arr(1,2);
      obj->shapePointsR(0,0) = points(0);
      obj->shapePointsR(0,1) = points(1);

      obj->visionCenter = arr(4);
           obj->visionCenter(0) = obj->shapePointsL(0,0);
           obj->visionCenter(1) = obj->shapePointsL(0,1);
           obj->visionCenter(2) =obj->shapePointsR(0,0);
           obj->visionCenter(3) = obj->shapePointsR(0,1);

      cvRectangle(CVMAT(disp), cvPoint(boxL(0),boxL(1)), cvPoint(boxL(2),boxL(3)), cvScalar(255,0,0), 3 );
      cvRectangle(CVMAT(disp), cvPoint(boxr(0),boxr(1)), cvPoint(boxr(2),boxr(3)), cvScalar(255,255,0), 3 );
    }
    objs.append(obj);
  }
  lock.writeLock();
  listDelete(objects);
  objects = objs;
  lock.unlock();
}



void realizeObjectListInOrs(ors::Graph& ors, const ObjectList& objects){
  Object *obj;  uint i;
  ors::Body *o = ors.getBodyByName("o1");
  uint indFirst = o->index;//hack to get consecutive bodies
  for_list(i,obj,objects){
    ors::Body *o = ors.bodies(i+indFirst);
    ors::Shape *s = o->shapes(0);
    int type;
    if( obj->shapeType == 0) type=1;
    if( obj->shapeType == 1) type=4;
    if( obj->shapeType == 2){//box
      type = 0;
      //  ors::Vector diag(obj->diagDiff(0),obj->diagDiff(1),obj->diagDiff(2)*0);//z is the smallest entry, but still not 0
      //real phi=acos(diag(0)/diag.length());//arccos btw 100 and diag
      // ors::Quaternion q;
      //q.setDiff(ors::Vector(1,0,0),diag);
      //q.setRad(phi,ors::Vector(0,0,1));
      // s->rel.r = q;
    }
    if(type!=s->type){
      s->type=type;
      s->mesh.clear();
    }
    // s->rel.p = -o->X.p + ors::Vector(obj->center3d(0),obj->center3d(1),obj->center3d(2));
    o->X.p =  ors::Vector(obj->center3d(0),obj->center3d(1),obj->center3d(2));
    memmove(s->size, obj->orsShapeParams.p,4*sizeof(double));
    //cout << " object " << o->name << " pos " << o->X.p << " " << obj->center3d << endl;
  }
}

/*void copyShapeInfos(ors::Graph& A,const ors::Graph& B){
  uint i; ors::Shape *s,*sa;
  for_list(i,s,B.shapes){
    sa = A.shapes(i);
    if(sa->type!=s->type){
      sa->type=s->type;
      sa->mesh.clear();
    }
    sa->rel=s->rel;
    memmove(sa->size, s->size, 4*sizeof(double));
  }
}*/

void copyBodyInfos(ors::Graph& A,const ors::Graph& B){
  uint i; ors::Body *b,*ba;
  ors::Shape *s,*sa;
  for_list(i,b,B.bodies) if(b->shapes.N){
    s = b->shapes(0);
    ba = A.bodies(i);
    sa = ba->shapes(0);
    if(sa->type!=s->type){
      sa->type=s->type;
      sa->mesh.clear();
    }
    ba->X= b->X;
    memmove(sa->size, s->size, 4*sizeof(double));   // if(b->index >= 17) cout << " pos " << ba->name << " " << ba->X.p << endl;
  }
}
