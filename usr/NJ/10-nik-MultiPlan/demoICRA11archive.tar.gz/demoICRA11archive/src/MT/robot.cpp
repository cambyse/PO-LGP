#include "robot.h"
#include "vision.h"
#include "revelModule.h"
#include "guiModule.h"

#include <lwa/Device/Device.h>
#ifdef MT_NILS
#  include <NP_2Drec/common.h>
#  include <NP_2Drec/vision_module.h>
#endif


#ifndef FORMAT
char outputbuf[200];
#define FORMAT(x) (sprintf(outputbuf,"%.2f",x)>0?outputbuf:NULL)
#define FORMATPM(x) (sprintf(outputbuf,"%.2f+-%.2f",x,sqrt(x##Var-x*x))>0?outputbuf:NULL)
#endif


//===========================================================================
//
// helpers
//

void q_hand_home(arr &q){
  q(10)=-.20; //thumb
  q(11)= .50;
  q( 8)=-.40; // index finger
  q( 9)= 1.1;
  q(12)=-.50; // pinky
  q(13)= 1.1;
}


//===========================================================================
//
// Robot Controller Module
//

ControllerModule::ControllerModule():timer("RobController"){
  maxJointStep = MT::Parameter<double>("maxJointStep");
  task=NULL;
  useBwdMsg=false;
  forceColLimTVs=true;
}

void ControllerModule::open(){
  //-- ors
  if(MT::checkParameter<MT::String>("orsFile")){
    MT::String sfile;
    MT::getParameter<MT::String>(sfile,"orsFile");
    MT::load(ors,sfile,true);
  }else MT::load(ors,"../../../share/configurations/schunk.ors",true);
  
  ors.calcNodeFramesFromEdges();
  ors.getJointState(q_reference,v_reference);
  q_home=q_reference;

  double cut = 0.11;
  if(MT::checkParameter<double>("swiftCutoff"))
     MT::getParameter(cut,"swiftCutoff");
  swift.init(ors,cut);
  swift.computeProxies(ors,false);
  
  // SOC interface
  arr W;
  W <<"[.1 .1 .2 .2 .2 1 1    .1 .1 .1 .1 .1 .1 .1]";
  //sys.initPseudoDynamic(&ors,&swift,NULL,2.,200,&W);
  sys.initBasics(&ors,&swift,NULL,400,4.,true,&W);
  task->initTaskVariables(this);

  timer.reset();
}

void ControllerModule::close(){
  listDelete(sys.vars);
}

void ControllerModule::step(){
  timer.cycleStart();
  
  //syncronize the ors/soc system with the true state q_ors and v_ors
  sys.setqv(q_reference,v_reference);

  //update the setting (targets etc) of the task variables -- might be set externally
  task->updateTaskVariables(this);
  
  //=== compute motion from the task variables
  //-- compute the motion step
  arr q_old=q_reference;
  arr dq,qv,qv_1;
  //check if a colition and limit variable are active
  bool colActive=false,limActive=false;
  uint i; TaskVariable *v;
  for_list(i,v,sys.vars) if(v->active){
    if(v->type==collTVT) colActive=true;
    if(v->type==qLimitsTVT) limActive=true;
  }
  if(forceColLimTVs && (!colActive || !limActive)) HALT("SAFETY BREACH! You need an active collision and limit variable!");

  /*OLD!!
    case 0:  //using the control variables directly
    updateState(sys.WS->vars);
      //reportAll(vars,cout);
    TV_lim->updateChange();
    bayesianControl(sys.WS->vars,dq,sys.WS->W);
    break;
    case 1: //inverse kinematics using SOC
    soc::bayesianIKControl(sys,dq,0);
    q_ors += dq;
    break;
    case 3: //iterated IK
    soc::bayesianIterateIKControl(sys,q_ors,q_old,0,1e-3,50);
    break;
  */

  //dynamic control using SOC
  qv_1=q_reference; qv_1.append(v_reference);
  if(!useBwdMsg) soc::bayesianDynamicControl(sys,qv,qv_1,0);
  else           soc::bayesianDynamicControl(sys,qv,qv_1,0,&bwdMsg_v,&bwdMsg_Vinv);
  q_reference = qv.sub(0,q_reference.N-1);
  v_reference = qv.sub(v_reference.N,-1);

  //SAFTY CHECK: too large steps?
  if(maxDiff(q_reference,q_old,NULL)>maxJointStep){
    MT_MSG(" *** WARNING *** too large step -> making no step,  |dq|="<<maxDiff(q_reference,q_old,NULL));
    q_reference=q_old;
    v_reference.setZero();
  }
  timer.cycleDone();
}

//===========================================================================
//
// Robot Module Master
//

RobotModuleGroup::RobotModuleGroup():ticcer("MasterTiccer",MT::getParameter<long>("tenMilliSeconds")),timer("MasterTimer"){
  //history=1000;
  //horizon=20;
  stepCounter=0;
  openArm=MT::Parameter<bool>("openArm");
  openHand=MT::Parameter<bool>("openHand");
  openSkin=MT::Parameter<bool>("openSkin");
  openJoystick=MT::Parameter<bool>("openJoystick");
  openLaser=MT::Parameter<bool>("openLaser");
  openBumble=MT::Parameter<bool>("openBumble");
  openEarlyVision=MT::Parameter<bool>("openEarlyVision");
  openGui=MT::Parameter<bool>("openGui");
  openThreadInfoWin=MT::Parameter<bool>("openThreadInfoWin",false);
  if(MT::checkParameter<MT::String>("logFile")){
    log = new ofstream;
    MT::open(*(ofstream*)log,MT::getParameter<MT::String>("logFile").p);
  }else log=NULL;
  if(MT::checkParameter<MT::String>("revelFile")){
    revel=new RevelInterface;
    revel->open(400,400,MT::getParameter<MT::String>("revelFile"));
  }
}
  
RobotModuleGroup::~RobotModuleGroup(){
  if(MT::checkParameter<MT::String>("logFile")){
    ((ofstream*)log)->close();
  }
}

void RobotModuleGroup::open(){
  uint m;
  float f;
  
  //setRRscheduling(MT::getParameter<int>("masterNice")); //requires SUDO
  if(!setNice(MT::getParameter<int>("masterNice")) && openHand) HALT("opening Schunk hand only with SUDO (for nice...)");
  
  //-- controller
  ctrl.open();
  motorIndex.resize(7);
  motorIndex(0) = ctrl.ors.getBodyByName("m3")->inLinks(0)->index;
  motorIndex(1) = ctrl.ors.getBodyByName("m4")->inLinks(0)->index;
  motorIndex(2) = ctrl.ors.getBodyByName("m5")->inLinks(0)->index;
  motorIndex(3) = ctrl.ors.getBodyByName("m6")->inLinks(0)->index;
  motorIndex(4) = ctrl.ors.getBodyByName("m7")->inLinks(0)->index;
  motorIndex(5) = ctrl.ors.getBodyByName("m8")->inLinks(0)->index;
  motorIndex(6) = ctrl.ors.getBodyByName("m9")->inLinks(0)->index;
//   swift.deactivate(TUPLE(
//                    ors.getBodyByName("fing1"),ors.getBodyByName("fing2"),ors.getBodyByName("fing3"),
//                    ors.getBodyByName("tip1"),ors.getBodyByName("tip2"),ors.getBodyByName("tip3")));

  if(openGui){
    gui.createOrsClones(&ctrl.ors);
    gui.ctrl=this;
    gui.threadOpen(MT::getParameter<int>("guiThreadNice"));
  }
  
  if(openJoystick){
    joy.open();
    do{ joy.step(); }while(joy.state(0)); //poll until buttons are clear
  }
  
  if(openBumble){
    bumble.threadOpen(MT::getParameter<int>("bumbleThreadNice"));
    bumble.step(); //get at least a first image
    bumble.threadLoop(); // -> start in loop mode!
  }

  if(openEarlyVision) evis.threadOpen(MT::getParameter<int>("evisThreadNice"));
  
  if(openHand) hand.threadOpen(MT::getParameter<int>("handThreadNice"));

  if(openArm){
#if defined MT_NO_THREADS & defined MT_SCHUNK
    HALT("don't open the arm without threads!");
#endif
    arm.threadOpen(MT::getParameter<int>("armThreadNice"));
#ifdef MT_SCHUNK
    for(m=3;m<=9;m++){ arm.pDev->setMaxVel(m, .1); }
    for(m=3;m<=9;m++){ arm.pDev->setMaxAcc(m, .1); }
    for(m=3;m<=9;m++){ arm.pDev->getPos(m,&f); ctrl.q_reference(motorIndex(m-3))=(double)f; } //IMPORTANT: READ IN THE CURRENT ARM POSTURE
#endif
    ctrl.v_reference.setZero();
    ctrl.sys.setqv(ctrl.q_reference,ctrl.v_reference);
  }

  if(openSkin){
    skin.threadOpen(MT::getParameter<int>("skinThreadNice"));
    skin.threadLoop();
  }

  if(openLaser){
    //laserfile.open("z.laser");
    urg.threadOpen(MT::getParameter<int>("laserThreadNice"));
  }

  if(openThreadInfoWin){
    globalThreadInfoWin.threadOpen();
  }
  
  //-- time initializations
  ticcer.reset();
  timer.reset();
}

void RobotModuleGroup::close(){
  if(openThreadInfoWin) globalThreadInfoWin.threadClose();
  if(openGui) gui.close();
  if(revel) revel->close();
  if(openLaser){  urg.threadClose(); /*laserfile.close();*/  }
  if(openBumble) bumble.threadClose();
  if(openArm)    arm.threadClose();
  if(openHand)   hand.threadClose();
  if(openSkin)   skin.threadClose();
  if(openEarlyVision) evis.threadClose();
}

void RobotModuleGroup::step(){
  uint m;
  stepCounter++;

  //wait for the next time tic
  ticcer.waitForTic();

  //=== NON THREADED STUFF
  
  //measure the busy & cycle time with a timer
  timer.cycleStart();
  
  if(openJoystick){
    joy.step();
    ctrl.joyState=joy.state;
  }

  //compute new q_reference
  ctrl.step();
  
  
  //=== THREADED STUFF: communication and triggering next steps

  //send arm motion signals
  if(openArm){
    for(m=0;m<7;m++) arm.q_reference(m) = (float)ctrl.q_reference(motorIndex(m));
    //here we DON'T COPY the true state into the simulator...
    arm.threadStepOrSkip(10);
  }

  //send hand motion
  if(openHand && hand.threadIsReady()){
    hand.v_reference.resize(7);
    for(m=0;m<=6;m++) hand.v_reference(m)=ctrl.v_reference(m+7);
    for(m=0;m<=6;m++) ctrl.q_reference(m+7)=hand.q_real(m);
    //here we COPY the true state into the simulator!
    hand.threadStep();
  }

  if(openSkin){ //loops permanently
    //if(skin.threadIsReady()) skin.threadStep();
    ctrl.skinState = skin.y_real;
  }

  if(openLaser && urg.threadIsReady()){
    urg.threadStep();
    //laserfile <<ctrl.ors.getShapeByName("lasershape")->X <<endl;
    //urg.scanline.writeTagged(laserfile,"scanline",false);
  }

  if(openBumble){ //loops permanently
    if(openGui){
      //if(openEarlyVision) gui.img[0]=evis.imgL;
      //else gui.img[0]=bumble.rgbL;
    }
  }

  if(openEarlyVision && evis.threadIsReady()){
    bumble.lock.readLock();
    evis.cameraL =bumble.rgbL; //frame;
    evis.cameraR =bumble.rgbR; //frame;
    bumble.lock.unlock();
    evis.threadStep();
  }

  if(openGui && gui.threadIsReady()){
    gui.q_reference=ctrl.q_reference;
    listCopy(gui.ors->proxies,ctrl.ors.proxies);
    gui.threadStep();
    if(revel){
      //CHECK(!useThreads,"don't use revel and threads!!");
      static uint revelCount=0;
      if(!(revelCount%4)) revel->addFrameFromOpengl();
      revelCount++;
    }
  }
  
  //timing output
  if(openThreadInfoWin) globalThreadInfoWin.threadStepOrSkip(100);

  //if(gui.isOpen) gui.step();
  timer.cycleDone();
}


//===========================================================================
//
// Task Abstraction
//

TaskAbstraction::TaskAbstraction(){
  plan_count=0.;
  joyRate = MT::Parameter<double>("joyRate");
  //-- planned trajectory
  if(MT::getParameter<bool>("loadPlanned")){
    ifstream fil;
    MT::open(fil,"z.plan");
    plan_v.readTagged(fil,"v");
    plan_Vinv.readTagged(fil,"Vinv");
    plan_b.readTagged(fil,"b");
    fil.close();
  }
  plan_speed = MT::getParameter<double>("plan_speed");

}

void TaskAbstraction::initTaskVariables(ControllerModule* ctrl){
  ors::Graph &ors=ctrl->ors;
  
  //define explicit control variables
  arr limits;
  limits <<"[-2. 2.; -2. 2.; -2. 0.2; -2. 2.; -2. 0.2; -3. 3.; -2. 2.; \
      -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5; -1.5 1.5 ]";
  //limits <<"[-2. 2.; -2. 2.; -2. 0.2; -2. 2.; -2. 0.2; -2. 2.; -2. 2.; 
  //    -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0; -1.0 1.0 ]";  
  
  arr skinIndex(6);
  skinIndex(0) = ors.getBodyByName("tip3")->index;
  skinIndex(1) = ors.getBodyByName("fing3")->index;
  skinIndex(2) = ors.getBodyByName("tip1")->index;
  skinIndex(3) = ors.getBodyByName("fing1")->index;
  skinIndex(4) = ors.getBodyByName("tip2")->index;
  skinIndex(5) = ors.getBodyByName("fing2")->index;
  
  
  TV_eff  = new TaskVariable("endeffector",ors, posTVT,"m9","<t(0 0 -.24)>",0,0,0);
  TV_rot  = new TaskVariable("endeffector rotation",ors, rotTVT,"m9",0,0,0,0);
  TV_col  = new TaskVariable("collision", ors, collTVT,0,0,0,0,ARR(.03)); //MARGIN, perhaps .05?
  TV_lim  = new TaskVariable("limits", ors, qLimitsTVT,0,0,0,0,limits);
  TV_q    = new TaskVariable("qitself", ors, qItselfTVT,0,0,0,0,0);
  TV_skin = new TaskVariable("skin", ors, skinTVT,0,0,0,0,skinIndex);
  TV_up   = new TaskVariable("up1",ors, zalignTVT,"m9","<d(90 1 0 0)>",0,0,0);
  TV_up2  = new TaskVariable("up2",ors, zalignTVT,"m9","<d( 0 1 0 0)>",0,0,0);
  TV_z1   = new TaskVariable("oppose12",ors,zalignTVT,"tip1","<d(90 1 0 0)>","tip2","<d( 90 1 0 0)>",0);
  TV_z2   = new TaskVariable("oppose13",ors,zalignTVT,"tip1","<d(90 1 0 0)>","tip3","<d( 90 1 0 0)>",0);
  TV_f1   = new TaskVariable("pos1",ors,posTVT,"tip1","<t( .0   -.09 .0)>",0,0,0);
  TV_f2   = new TaskVariable("pos2",ors,posTVT,"tip2","<t( .033 -.09 .0)>",0,0,0);
  TV_f3   = new TaskVariable("pos3",ors,posTVT,"tip3","<t(-.033 -.09 .0)>",0,0,0);

  TVall.append(TUPLE(TV_eff,TV_rot,TV_col,TV_lim,TV_q,TV_skin));
  TVall.append(TUPLE(TV_up,TV_up2,TV_z1,TV_z2,TV_f1,TV_f2,TV_f3));
  ctrl->sys.setTaskVariables(TVall);
  
  TV_x_yprec  = MT::Parameter<double>("TV_x_yprec");
  TV_x_vprec  = MT::Parameter<double>("TV_x_vprec");
  TV_rot_vprec= MT::Parameter<double>("TV_rot_vprec");
  TV_q_vprec  = MT::Parameter<double>("TV_q_vprec");
  
#ifndef VELC
  TV_eff->active=true;    TV_eff->targetType=directTT;    TV_eff  ->y_prec=TV_x_yprec;   TV_eff->v_prec=0;
#else
  TV_eff->active=true;    TV_eff->targetType=directTT;    TV_eff  ->y_prec=0;     TV_eff->v_prec=TV_x_vprec;
#endif
  TV_rot->active=true;  TV_rot->targetType=directTT;  TV_rot->y_prec=0;     TV_rot->v_prec=TV_rot_vprec;
  TV_col->active=true;  TV_col->targetType=directTT;  TV_col->y_prec=MT::Parameter<double>("TV_col_yprec"); TV_col->v_prec=0;
  TV_lim->active=true;  TV_lim->targetType=directTT;  TV_lim->y_prec=MT::Parameter<double>("TV_lim_yprec"); TV_lim->v_prec=0;
  TV_q  ->active=true;  TV_q->targetType=directTT;    TV_q  ->y_prec=0;     TV_q->v_prec=TV_q_vprec;
  TV_skin->active=true; TV_skin->targetType=directTT; TV_skin->y_prec=MT::Parameter<double>("TV_skin_yprec"); TV_skin->v_prec=0;

  TV_z1->active=false;
  TV_z2->active=false;
  TV_f1->active=false;
  TV_f2->active=false;
  TV_f3->active=false;
  TV_up->active=false;
  TV_up2->active=false;
}

void TaskAbstraction::updateTaskVariables(ControllerModule* ctrl){
  if(ctrl->skinState.N){
    TV_skin->y = ctrl->skinState; //can get this state only from sensors!
    //cout <<"\r" <<TV_skin->y <<flush;
  }else{
    TV_skin->y=ARR(.01,0,.01,0,.01,0);
  }

  if(!(controlMode==joystickCM && ctrl->joyState(0)==2)){
    //cut of the skin signal... :-(
    for(uint i=0;i<TV_skin->y.N;i++) if(TV_skin->y(i)>.02) TV_skin->y(i)=.02;
    //nil certain parts of the skin jacobian: all arm joints and hand 0-joint... :-(
    for(uint i=0;i<TV_skin->J.d0;i++) for(uint j=0;j<8;j++) TV_skin->J(i,j)=0.;
    transpose(TV_skin->Jt,TV_skin->J);
  }

  //-- first deactivate every task (and bwd msg)!
  activateAll(TVall,false);
  ctrl->useBwdMsg=false;
    
  switch(controlMode){
    case joystickCM:{
      TV_col->active=true;
      TV_lim->active=true;
      
      TV_q->active=true;
      TV_q  ->y_prec=0.;   TV_q->v_prec=TV_q_vprec;  TV_q->v_target.setZero(); //damping on joint velocities
      
      switch(ctrl->joyState(0)){
        case 1:{ //(1) homing
          TV_q->v_target = ctrl->q_home - TV_q->y;
          double vmax=.5,v=norm(TV_q->v_target);
          if(v>vmax) TV_q->v_target*=vmax/v;
          break;
        }
        case 2:{ //(2) CRAZY tactile guiding
          TV_skin->active=true;
          TV_skin->y_target=ARR(.00,0,.00,0,.00,0);
          //ON SIMULATION: since it is set to (.01,.01,.01) this will always give a repelling force!
          break;
        }
        case 256:{ //(select)close hand
          TV_skin->active=true;
          TV_skin->y_target=ARR(.02,0,.02,0,.02,0);
          break;
        }
        case 512:{ //(start)open hand
#if 1
          TV_q->active=true;
          TV_q->y_prec=1e1;  TV_q->v_prec=TV_q_vprec;  TV_q->v_target.setZero();
          TV_q->y_target = TV_q->y;
          TV_q->y_target( 8)=TV_q->y_target(10)=TV_q->y_target(12)=-.8;
          TV_q->y_target( 9)=TV_q->y_target(11)=TV_q->y_target(13)= .6;
#else
          TV_skin->active=true;
          TV_skin->y_target.setZero();
#endif
          break;
        }
        case 8:{ //(4) motion rate without rotation
          TV_rot->active=true;
          TV_rot->y_prec=0.;  TV_rot->v_prec=TV_rot_vprec;
          TV_rot->v_target.setZero();
        }
        case 0:{ //(NIL) motion rate control
          TV_eff ->active=true;
          TV_eff->y_target = TV_eff->y;
          TV_eff->y_prec=0.;  TV_eff->v_prec=TV_x_vprec;
          TV_eff->v_target(0) = -joyRate*MT::sign(ctrl->joyState(3))*(.25*(exp(MT::sqr(ctrl->joyState(3))/10000.)-1.));
          TV_eff->v_target(1) = +joyRate*MT::sign(ctrl->joyState(6))*(.25*(exp(MT::sqr(ctrl->joyState(6))/10000.)-1.));
          TV_eff->v_target(2) = -joyRate*MT::sign(ctrl->joyState(2))*(.25*(exp(MT::sqr(ctrl->joyState(2))/10000.)-1.));
          break;
        }
        case 4:{ //(3) controlling the rotation rate
          TV_eff ->active=true;
          TV_rot->active=true;
          TV_eff->y_prec=TV_x_yprec;  TV_eff->v_prec=0.;
          TV_rot->y_prec=0.; TV_rot->v_prec=TV_rot_vprec;
          TV_rot->v_target(0) = -3.*joyRate*MT::sign(ctrl->joyState(3))*(.25*(exp(MT::sqr(ctrl->joyState(3))/10000.)-1.));
          TV_rot->v_target(1) = +3.*joyRate*MT::sign(ctrl->joyState(6))*(.25*(exp(MT::sqr(ctrl->joyState(6))/10000.)-1.));
          TV_rot->v_target(2) = -3.*joyRate*MT::sign(ctrl->joyState(1))*(.25*(exp(MT::sqr(ctrl->joyState(1))/10000.)-1.));
          break;
        }
        /*
        case 512:{ //follow a planned trajectory!
        if((uint)plan_count>=plan_v.d0){ cout <<"trajectory following done..." <<endl;  break; }
          //TV_col->params(0)=.02;
        v_ref   .referToSubDim(plan_v,(uint)plan_count);
        Vinv_ref.referToSubDim(plan_Vinv,(uint)plan_count);
        plan_count+=plan_speed;
        bwdMsgs=true;
        break;
      }*/
       //grip_target = ((double)(ctrl->joyState(7)/4))/5.;
      }
      break;
    }
    case followTrajCM:{
      cout <<"\r plan_count=" <<plan_count <<flush;
      if((uint)plan_count>=plan_v.d0){ cout <<"trajectory following done..." <<endl;  break; }
      //TV_col->params(0)=.02;
      TV_col->active=true;
      TV_lim->active=true;
      
      ctrl->bwdMsg_v   .referToSubDim(plan_v,(uint)plan_count);
      ctrl->bwdMsg_Vinv.referToSubDim(plan_Vinv,(uint)plan_count);
      plan_count+=plan_speed;
      ctrl->useBwdMsg=true;
      break;
    }
    case closeHandCM:{
      TV_col->active=true;
      TV_lim->active=true;
      TV_skin->active=true;
      TV_q->active=true;

      TV_q->y_prec=0.;  TV_q->v_prec=TV_q_vprec;  TV_q->v_target.setZero();
      TV_skin->y_target=ARR(.02,0,.02,0,.02,0);

      //if(log) (*log) <<"\r CLOSE HAND " <<TV_skin->y <<flush;
      break;
    }
    case openHandCM:{
      TV_col->active=true;
      TV_lim->active=true;
      //TV_skin->active=true;
      TV_q->active=true;

      TV_q->y_prec=1e1;  TV_q->v_prec=TV_q_vprec;  TV_q->v_target.setZero();
      TV_q->y_target = TV_q->y;
      TV_q->y_target( 8)=TV_q->y_target(10)=TV_q->y_target(12)=-.8;
      TV_q->y_target( 9)=TV_q->y_target(11)=TV_q->y_target(13)= .6;
      //TV_skin->y_target.setZero();
      break;
    }
    case reachCM:{
      CHECK(reachPoint.N==3,"");
      TV_eff->active = true;
      TV_eff->y_prec=0.;  TV_eff->v_prec=1e-1;
      TV_eff->v_target=reachPoint - TV_eff->y;
      double vmax=.2,v=norm(TV_eff->v_target);
      if(v>vmax) TV_eff->v_target*=vmax/v;
      break;
    }
    case stopCM:{
      TV_col->active=true;
      TV_lim->active=true;
      TV_q->active=true;
      TV_q  ->y_prec=0.;   TV_q->v_prec=TV_q_vprec;  TV_q->v_target.setZero();
      break;
    }
    default: NIY
  }
}
      
bool RobotModuleGroup::signalStop=false;
void RobotModuleGroup::signalStopCallback(int){
  signalStop=true;
}


