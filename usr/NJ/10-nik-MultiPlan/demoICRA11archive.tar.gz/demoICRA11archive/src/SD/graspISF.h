#ifndef SD_graspISF_h
#define SD_graspISF_h

#include <MT/array.h>
#include <MT/opengl.h>
#include <MT/ors.h>
#include <MT/ors_swift.h>
#include <MT/soc.h>
#include <MT/ors_taskVariables.h>

#include "utils.h"

struct grasp_ISF{

  
  /* == environment configuration and variables == */
  ors::Graph *G;
  OpenGL *gl;
  SwiftModule  *swift; 
  soc::SocSystem_Ors *soc;
  arr q;

  struct LoopPars{
    arr nabla_fx_t;
    double fx_t;
    double fing_ori_prec_boost;
  };

  /* == algorithm configuration and vars == */
  MT::Array<const char *> tips;// finger endeffector bodies
  const char *tip_rel; // f-tip endeffector face relative to tip body
  ors::Frame tip_frame;

  const char *wrist; // palm body
  const char *palm_rel; // palm center wrt wrist body
  ors::Frame palm_frame;

  uint t, T; // time index and max steps
  double  pos_gain, // exp rate of error correction 
          ori_gain, 
          pos_ampl, // amplification of direction vector
          err_threshold; // sum of errors of taskVars below which loop stops

  const char *grasp_target;// name of the body ?why for switsching off collisions?

  grasp_ISF(const char *ors_file);
  ~grasp_ISF(){/*TODO*/}

  void init(const char *ors_file);// environment configuration
  void config();// environment configuration
  void setTaskVariables(); // task variable configuration

  virtual double func_ISF(const arr& x) = 0; //pointer to implicit shape function
  virtual void grad_ISF(arr &grad, const arr& x) = 0; //pointer to ISF gradient
  double get_ISF_value(const char * body, ors::Frame &fr);
  void get_ISF_grad(arr &grad, const char * body, ors::Frame &fr);

  virtual void loop();
  virtual bool loop_condition();

  TaskVariableList TVs_pos; // pos TaskVars for the fingers
  TaskVariableList TVs_z_ori; // orientation TV for the fingers
  TaskVariable *TV_palm_z; // orientation TaskVar for the palm
  TaskVariable *TV_palm; // position TaskVar for the palm

  double max_fx;

  // plot data
  arr plot_data; // here we collect the data to plot
  virtual void plot_append_data(); // this is invoked in every loop 
  void plot_all(); // invoked after loop finishes

  /* == tools == */

  double gradient_orientation();

};

#include "graspISF.cpp"


#endif// header ifdef
