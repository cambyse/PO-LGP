#include "graspISF.h"
#include<MT/plot.h>
#include <MT/ors_opengl.h>

void
drawEnv2(void*){
  glStandardLight();
}

void
init_gl(OpenGL *gl,ors::Graph *G){
  //init graph and camera
  gl->add(ors::glDrawGraph,G);
  //gl.add(plotDrawOpenGL,&plotData);
  gl->camera.focus(0,0,.8);
  plotModule.drawDots = true;
  plotModule.thickLines = 3;
  gl->add(drawEnv2,0);
  gl->setClearColors(.7,.8,.4,1.); 
  gl->update();
}

/** invokes the environment configureation and the TaskVariable setup */
grasp_ISF::grasp_ISF(const char *ors_file){

  // prepare environment
  init(ors_file);

  // configure the algoritm
  config();

  // configure task vars
  setTaskVariables();
}

/** Configure the environment */
void
grasp_ISF::init(const char * ors_file){

  swift = new SwiftModule();
  G = new ors::Graph();
  gl = new OpenGL("robot",640,400,100,100);
  init_gl(gl, G);
  soc = new soc::SocSystem_Ors();

  // init the graph
  MT::load(*G,ors_file, true);

  // configuration space
  G->getJointState(q);


  T=800;
  soc->initKinematic(G,swift,gl,T);
  soc->os=&std::cout;

}

/** set the controller parameters */
void
grasp_ISF::config(){
  uint i;

  // finger tip endeffector
  tips.append("tip1");
  tips.append("tip2");
  tips.append("tip3");

  tip_rel = "<t(0 -.014 .009) d(80 1 0 0)>";
  tip_frame.setText(tip_rel);
  // wrist endeffector
  wrist = "m9";
  palm_rel = "<d(180 1 0 0) t(0 0 0.1500) d(-90 0 0 1)>"; 
  palm_frame.setText(palm_rel);

  grasp_target = "graspTarget";

  // init collision module
  swift->init(*G, .08);
  FORStringList(i, tips)
    swift->deactivate(TUPLE( G->getBodyByName(tips(i)), G->getBodyByName(grasp_target))) ;
  swift->computeProxies(*G, false);      // print: false

  // gains
  pos_gain = .2;
  ori_gain = .2;
  pos_ampl = .1;
  err_threshold = .0005; // half mm if seen as distance (but it's *precision)
  max_fx = 1.;
}

/** Create the TaskVariables to use in the update loop: one for palm
 * orientation, and for each finger  one for orientation and one for position.
 * Use the body names and the relative frames as defined in the init
 */
void
grasp_ISF::setTaskVariables(){
  uint i;

  TaskVariableList TVs;
  TaskVariable *tv;

  // Create pos variables
  FORStringList(i, tips){
    tv = new TaskVariable(
        STRING("pos "<<tips(i)),*G, posCVT,tips(i),tip_rel,0,0,ARR());
    tv->setGains(pos_gain,0);
    tv->prec = 50;
    TVs_pos.append(tv);
    TVs.append(tv);
  }

  // finger tips orientation (aligned with gradient)
  FORStringList(i, tips){
    tv = new TaskVariable(
        STRING("z ori "<<tips(i)),*G, zoriCVT,tips(i),tip_rel,0,0,ARR());
    tv->prec = 50;
    tv->setGains(ori_gain,.0);
    TVs_z_ori.append(tv);
    TVs.append(tv);
  }

  // palm orientation
  TV_palm_z = new TaskVariable(
      "z palm",*G, zoriCVT,wrist,palm_rel,0,0,ARR());
  TV_palm_z->setGains(ori_gain,0);
  TV_palm_z->prec = 50;
  TVs.append(TV_palm_z);

  // palm position
  TV_palm = new TaskVariable(
      "palm pos",*G, posCVT,wrist,palm_rel,0,0,ARR());
  TV_palm->prec = 50;
  TV_palm->setGains(pos_gain,.0);
  TVs.append(TV_palm);

  soc->setTaskVariables(TVs);

}

void
grasp_ISF::get_ISF_grad(arr &grad, const char * body, ors::Frame &fr){
  arr x, tmp;
  double m;
  uint idx;

  SD_DBG3("body: "<<body<<" ------");
  idx = G->getBodyByName(body)->index;
  G->kinematics(x, idx, &fr);
  SD_DBG3("y "<<x);
  grad_ISF(grad, x);
  SD_DBG3("nabla "<<grad);
  // find closest to 0 non-0 element
  tmp = fabs(grad);
  m = tmp.max();
  if (m == 0) return; // gradient is 0; don't try to normalize
  for(uint i=0; i<tmp.N; ++i)   m = (tmp(i)==0 || m<=tmp(i)?m:tmp(i));
  grad /= m; // cure the numeric issues with small gradients ~1e-270
  SD_DBG3("nabla /= min(abs(nabla)) "<<grad);
  grad /= norm(grad);
  SD_DBG3("nabla /= norm "<<grad);
}

double
grasp_ISF::get_ISF_value(const char * body, ors::Frame &fr){
  arr x;
  uint idx;

  SD_DBG3("body: "<<body<<" ------");
  idx = G->getBodyByName(body)->index;
  G->kinematics(x, idx, &fr);
  SD_DBG3("y "<<x);
  return func_ISF(x);
}

/** Loop and update TaskVariables while condition holds and t<T */
void
grasp_ISF::loop(){

  arr nabla_fx_t;
  arr sum_fing_gradient; 
  double fx_t;
  double fing_ori_prec_boost;
  uint i;

  soc->getq0(q);

  gl->watch("Press <ENTER> to start loop!");

  for(t=0; ; ++t){

    fx_t = get_ISF_value(wrist, palm_frame);
    get_ISF_grad(nabla_fx_t, wrist, palm_frame);

    // palm orientation
    TV_palm->x_target = TV_palm->x - nabla_fx_t * pos_ampl * (fx_t/max_fx);

    // palm orientation
    TV_palm_z->x_target = - nabla_fx_t;
    TV_palm_z->prec = 10 + (fx_t/max_fx) * 90; // more freedom to finger when near obj

    // finger tips Task Variables
    fing_ori_prec_boost = (1./tips.N)*(tips.N - gradient_orientation());
    FORStringList(i, tips){
      fx_t = get_ISF_value(tips(i), tip_frame);
      get_ISF_grad(nabla_fx_t, tips(i), tip_frame);

      // position variable
      TVs_pos(i)->x_target = TVs_pos(i)->x - nabla_fx_t * pos_ampl * (100 * fx_t/max_fx);

      // orientation
      TVs_z_ori(i)->x_target =  - nabla_fx_t;
      // start finger orientation when gradients not parallel
      TVs_z_ori(i)->prec = 0 + fing_ori_prec_boost * 100;
    }

    plot_append_data();

    soc::bayesianIKControl2(*soc,q,q,0);
    soc->setq(q);
    gl->update(STRING("step " << t+1<<" of "<<T));
    if (!loop_condition()) break;
  }

  gl->watch(STRING("steps:" << t+1<<". press <ENTER>"));
  plot_all();
}

/** collect data to plot. */
void
grasp_ISF::plot_append_data(){
  uint i;
  arr nabla_fx_t;
  double fx_t;

  fx_t = get_ISF_value(wrist, palm_frame);
  get_ISF_grad(nabla_fx_t, wrist, palm_frame);

  plot_data.append(fx_t); // 0
  plot_data.append(TV_palm_z->err); //1
  plot_data.append(TV_palm_z->prec);//2

  plot_data.append(gradient_orientation()); //3
  plot_data.append((1./tips.N)*(tips.N - gradient_orientation()));//4

  FORStringList(i, tips){
    fx_t = get_ISF_value(tips(i), tip_frame);
    get_ISF_grad(nabla_fx_t, tips(i), tip_frame);

    plot_data.append(fx_t);//5,9,13
    plot_data.append(TVs_pos(i)->err);//6,10,14
    plot_data.append(TVs_z_ori(i)->err);//7,11,15
    plot_data.append(TVs_z_ori(i)->prec);//8,12,16
  }
}

/** after the loop plot the collected data */
void
grasp_ISF::plot_all(){
  uint samples = plot_data.N/17,
       graphs = 17;
  arr plot_data_t;

  soc->reportOnState(cout); 
  //plot
  plotGnuplot();

  plot_data.reshape( samples, graphs );
  plotFunctions(plot_data);
  plot(true);
  
  SD_INF("Please use plot.sh for a better visual experience!")
  
  plotOpengl();
}

/** Scalar between 0 and (#fingers). increasing means gradient points in similar
 * directions. Value of (#fingers) means gradients at fingertips are parallel.
 * Value of 0 means gradients are as opposite as it gets.
 */
double
grasp_ISF::gradient_orientation(){
    uint i;
    arr nabla_fx_t; 
    arr sum = ARR(0, 0, 0);

    FORStringList(i, tips){
      get_ISF_grad(nabla_fx_t, tips(i), tip_frame);

      // position variable
      sum += nabla_fx_t;
    }
    return norm(sum);
}

bool
grasp_ISF::loop_condition(){
  uint i;

  // if max iterations
  if ( T <= t ) return false;

  // if above error
  FORStringList(i, soc->WS->vars)
    if ( soc->WS->vars(i)->active 
        && (soc->WS->vars(i))->err > err_threshold) return true;
  return false;
}
