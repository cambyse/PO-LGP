
#ifndef SD_rbf_h
#define SD_rbf_h

#include <MT/array.h>

/**  exp(- s * dist ) */
double
RBF_gauss( const double s, const double dist){
  return  ::exp( - s * dist*dist ) ;
}

/** RBFupside down and translated to center c, pushed up so that as ISF defines
 * a sphere with radius r around c. */
double
ISF_RBF_gauss(const arr &c, const double s, const double r, const arr &x){
  return  - RBF_gauss(s, norm(x-c)) + RBF_gauss(s, r); 
}

void
ISF_RBF_gauss_gradient(arr& grad, const arr& x){
    arr c;
    if(x.N == 3)
      c = ARR(ISF_RBF_gauss_param(GET,C1),
          ISF_RBF_gauss_param(GET,C2),
          ISF_RBF_gauss_param(GET,C3));
    else
      c = ARR(ISF_RBF_gauss_param(GET,C1),
          ISF_RBF_gauss_param(GET,C2));
    double s = ISF_RBF_gauss_param(GET,SIG);
    
    grad = (-2*s*(c - x)) * ISF_RBF_gauss(x);
}

#endif// header ifdef
